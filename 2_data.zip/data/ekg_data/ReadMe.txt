Daten sind mit f=1000 Hz aufgezeichnet worden

Spalte 1: Zeit
Spalte 2: Messwerte (mV)