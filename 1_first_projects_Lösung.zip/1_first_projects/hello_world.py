#Kommentar
#%% Block Comment

print("Hello, World!")


# %%
