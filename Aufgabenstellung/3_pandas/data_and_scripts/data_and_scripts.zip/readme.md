# Structure of Programmierübung 3

1. 1. loading data + different data formats 
     - Numpy arrays
     - Pandas dataframes
     - Lists
2. Working with pandas
     -  Structure of dataframes
     -  Storing and Loading CSV-Files
     -  Advanced pandas
     -  Group by
     -  Operations on columns
     -  Creating new columns
     -  Simple analysis
3. Graphing data
     - Matplotlib
     - Seaborn
     - Plotly 
4. Tasks:
      1. Pandas
      2. Matplotlib
      3. Pandas Visualization
      